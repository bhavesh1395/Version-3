import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Play, Pause } from 'lucide-react';

const apologyText = "Dear Shiksha,\n\nI am so incredibly sorry for how I acted. You mean the world to me, and seeing you upset breaks my heart. I was stupid, and I promise to do better.\n\nLooking back at all these memories reminds me of how lucky I am to have you in my life. This friendship is too beautiful to let my foolishness ruin it.\n\nPlease forgive me. ❤️\n\nYour Bhavesh";

export function ApologyLetter() {
  const [isOpen, setIsOpen] = useState(false);
  const [displayedText, setDisplayedText] = useState("");
  const [isPlaying, setIsPlaying] = useState(false);
  
  const textRef = useRef<HTMLDivElement>(null);
  const speechRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    if (isOpen) {
      let i = 0;
      setDisplayedText("");
      const interval = setInterval(() => {
        setDisplayedText(apologyText.slice(0, i));
        i++;
        if (textRef.current) {
           textRef.current.scrollTop = textRef.current.scrollHeight;
        }
        if (i > apologyText.length) {
          clearInterval(interval);
        }
      }, 40); // Typing speed
      return () => clearInterval(interval);
    }
  }, [isOpen]);

  // Premium, Natural Speech Synthesis Controller
  useEffect(() => {
    if (!isPlaying) {
      window.speechSynthesis.cancel();
      return;
    }

    // Filter out emojis for clear narration
    const narrationText = apologyText.replace(/❤️/g, '').trim();
    const utterance = new SpeechSynthesisUtterance(narrationText);
    speechRef.current = utterance;

    // Retrieve high quality natural or female voices
    const loadVoicesAndSpeak = () => {
      const voices = window.speechSynthesis.getVoices();
      
      // Select the finest premium natural female voices
      const preferredVoice = voices.find(v => 
        (v.name.includes('Google') && v.name.includes('US English') && v.name.toLowerCase().includes('female')) ||
        (v.name.includes('Natural') && v.lang.startsWith('en')) ||
        v.name.includes('Samantha') ||
        v.name.includes('Zira') ||
        v.name.includes('Google US English') ||
        v.name.toLowerCase().includes('female')
      ) || voices.find(v => v.lang.startsWith('en')) || voices[0];

      if (preferredVoice) {
        utterance.voice = preferredVoice;
      }

      // Emotional tender pacing configuration
      utterance.rate = 0.82;   // elegant slow pacing
      utterance.pitch = 1.05;  // warm bright tone
      utterance.volume = 1.0;  // full audibility

      utterance.onend = () => setIsPlaying(false);
      utterance.onerror = () => setIsPlaying(false);

      window.speechSynthesis.speak(utterance);
    };

    // Chrome/Safari voice lazy loading guard
    if (window.speechSynthesis.getVoices().length > 0) {
      loadVoicesAndSpeak();
    } else {
      window.speechSynthesis.onvoiceschanged = loadVoicesAndSpeak;
    }

    return () => {
      window.speechSynthesis.cancel();
    };
  }, [isPlaying]);

  return (
    <div className="w-full min-h-[80vh] flex flex-col items-center justify-center p-4 relative z-20">
      
      {!isOpen ? (
        <motion.div
          animate={{ y: [0, -15, 0] }}
          transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
          onClick={() => setIsOpen(true)}
          className="cursor-pointer group relative"
        >
          <div className="absolute text-center -top-16 left-1/2 -translate-x-1/2 w-full text-rose-200 font-serif italic text-lg opacity-0 group-hover:opacity-100 transition-opacity">
            A message for you...
          </div>
          
          {/* Glowing Aura */}
          <div className="absolute inset-0 bg-rose-500/40 blur-3xl rounded-full scale-150 group-hover:bg-rose-500/60 transition-colors duration-500" />
          
          {/* The Envelope */}
          <div className="relative bg-[#f1f5f9] w-72 md:w-80 h-48 md:h-56 rounded-lg shadow-2xl flex items-center justify-center overflow-hidden group-hover:scale-105 transition-transform duration-500">
             {/* Envelope Flaps via borders */}
             <div className="absolute inset-0 border-t-[40px] md:border-t-[50px] border-t-slate-300 border-x-[144px] md:border-x-[160px] border-x-transparent border-b-[96px] md:border-b-[112px] border-b-slate-200 opacity-90" />
             
             {/* Wax Seal */}
             <div className="absolute text-rose-600 flex flex-col items-center justify-center drop-shadow-xl bg-rose-100 w-16 h-16 rounded-full border-2 border-rose-300 z-10">
                <Heart fill="currentColor" size={28} className="animate-pulse" />
             </div>
          </div>
        </motion.div>
      ) : (
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, y: 50, rotateX: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0, rotateX: 0 }}
          transition={{ type: "spring", damping: 15 }}
          className="bg-[#fcfaf8] w-full max-w-2xl p-8 md:p-14 rounded-sm shadow-[0_20px_50px_rgba(0,0,0,0.5)] text-slate-800 font-serif relative"
        >
          {/* Decorative elements */}
          <div className="absolute top-6 right-6 opacity-10 pointer-events-none">
             <Heart size={120} fill="currentColor" className="text-rose-500" />
          </div>
          
          <div 
            ref={textRef}
            className="whitespace-pre-wrap text-[17px] md:text-xl leading-[1.8] md:leading-[2] min-h-[350px] z-10 relative text-slate-700 tracking-wide"
          >
            {displayedText}
            {displayedText.length < apologyText.length && (
              <span className="inline-block w-2 h-5 bg-rose-400 ml-1 animate-pulse align-middle" />
            )}
          </div>

          <AnimatePresence>
            {displayedText.length === apologyText.length && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1, duration: 1 }}
                className="mt-12 flex flex-col items-center border-t border-slate-200/60 pt-10"
              >
                 <p className="text-xs text-slate-400 mb-6 uppercase tracking-[0.2em] font-sans">A Personal Message</p>
                 <button 
                   onClick={() => setIsPlaying(!isPlaying)}
                   className="flex items-center gap-3 bg-slate-900 hover:bg-rose-600 text-white px-8 py-4 rounded-full shadow-lg transition-all duration-300 hover:scale-105 active:scale-95 group"
                 >
                    {isPlaying ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-1" />}
                    <span className="font-sans font-medium tracking-wide">
                      {isPlaying ? "Pause Message" : "Play Voice Message"}
                    </span>
                 </button>
                 
                 {isPlaying && (
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="mt-6 flex gap-1 items-center h-8"
                    >
                      {[...Array(5)].map((_, i) => (
                        <motion.div
                          key={i}
                          className="w-1.5 bg-rose-400 rounded-full"
                          animate={{ height: ['4px', '24px', '4px'] }}
                          transition={{ repeat: Infinity, duration: 0.8, delay: i * 0.15 }}
                        />
                      ))}
                    </motion.div>
                 )}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </div>
  );
}
