import { motion } from "motion/react";

export function Atmosphere() {
  return (
    <div className="fixed inset-0 pointer-events-none z-[0] overflow-hidden">
      {/* Shifting Gradient */}
      <motion.div 
        className="absolute inset-0 opacity-70"
        animate={{
          background: [
            "linear-gradient(to bottom, #1e1b4b, #312e81, #000000)", // Night
            "linear-gradient(to bottom, #7c2d12, #9d174d, #1e1b4b)", // Sunset
            "linear-gradient(to bottom, #1e1b4b, #312e81, #000000)", // Night
          ]
        }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
      />
      
      {/* Fireflies */}
      {[...Array(25)].map((_, i) => (
        <motion.div
          key={`firefly-${i}`}
          className="absolute rounded-full bg-amber-200"
          style={{
            width: Math.random() * 4 + 2 + 'px',
            height: Math.random() * 4 + 2 + 'px',
            boxShadow: '0 0 12px 3px rgba(253,224,71,0.6)',
            top: Math.random() * 100 + '%',
            left: Math.random() * 100 + '%',
          }}
          animate={{
            y: [0, -100, -200],
            x: [0, Math.random() * 60 - 30, Math.random() * 60 - 30],
            opacity: [0, Math.random() * 0.8 + 0.2, 0],
          }}
          transition={{
            duration: Math.random() * 12 + 10,
            repeat: Infinity,
            ease: "easeInOut",
            delay: Math.random() * 10,
          }}
        />
      ))}
      
      {/* Cherry Blossoms */}
      {[...Array(15)].map((_, i) => (
        <motion.div
          key={`petal-${i}`}
          className="absolute bg-pink-300/30 rounded-full blur-[1px]"
          style={{
            width: Math.random() * 12 + 6 + 'px',
            height: Math.random() * 8 + 4 + 'px',
            top: -20,
            left: Math.random() * 100 + '%',
            borderRadius: '50% 0 50% 0',
          }}
          animate={{
            y: ['0vh', '110vh'],
            x: [0, Math.random() * 100 - 50, Math.random() * 200 - 100],
            rotate: [0, 360],
          }}
          transition={{
            duration: Math.random() * 15 + 15,
            repeat: Infinity,
            ease: "linear",
            delay: Math.random() * 15,
          }}
        />
      ))}
    </div>
  );
}
