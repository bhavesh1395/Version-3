import { useEffect, useRef } from 'react';

interface Star {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  decay: number;
  rotation: number;
  rotationSpeed: number;
  type: 'sparkle' | 'star' | 'circle';
}

export function CursorButterflies() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // HTML5 Canvas Star Trail Animation Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    let animationId: number;
    const stars: Star[] = [];
    let starIdCounter = 0;

    const updateAndDraw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (let i = stars.length - 1; i >= 0; i--) {
        const star = stars[i];
        // Move star
        star.x += star.vx;
        star.y += star.vy;
        
        // Soft gravity drift down
        star.vy += 0.02;
        
        // Soft friction / deceleration
        star.vx *= 0.97;
        star.vy *= 0.97;

        // Spin
        star.rotation += star.rotationSpeed;
        
        // Decay opacity - make it quick to vanish as user requested
        star.alpha -= star.decay;

        if (star.alpha <= 0) {
          stars.splice(i, 1);
          continue;
        }

        // Draw star
        ctx.save();
        ctx.translate(star.x, star.y);
        ctx.rotate(star.rotation);
        ctx.globalAlpha = star.alpha;
        ctx.fillStyle = star.color;
        
        // Removed shadowBlur to drastically improve mobile performance
        // ctx.shadowBlur = star.size * 2;
        // ctx.shadowColor = star.color;

        if (star.type === 'sparkle') {
          // Sharp 4-point magical lens sparkle
          const spikes = 4;
          const outer = star.size;
          const inner = star.size * 0.18;
          let rot = -Math.PI / 2;
          const step = Math.PI / spikes;

          ctx.beginPath();
          ctx.moveTo(0, -outer);
          for (let j = 0; j < spikes; j++) {
            let x = Math.cos(rot) * outer;
            let y = Math.sin(rot) * outer;
            ctx.lineTo(x, y);
            rot += step;

            x = Math.cos(rot) * inner;
            let y2 = Math.sin(rot) * inner;
            ctx.lineTo(x, y2);
            rot += step;
          }
          ctx.closePath();
          ctx.fill();
        } else if (star.type === 'star') {
          // 5-point classic star
          const spikes = 5;
          const outer = star.size * 0.7;
          const inner = star.size * 0.3;
          let rot = -Math.PI / 2;
          const step = Math.PI / spikes;

          ctx.beginPath();
          ctx.moveTo(0, -outer);
          for (let j = 0; j < spikes; j++) {
            let x = Math.cos(rot) * outer;
            let y = Math.sin(rot) * outer;
            ctx.lineTo(x, y);
            rot += step;

            x = Math.cos(rot) * inner;
            let y2 = Math.sin(rot) * inner;
            ctx.lineTo(x, y2);
            rot += step;
          }
          ctx.closePath();
          ctx.fill();
        } else {
          // Tiny round light orb
          ctx.beginPath();
          ctx.arc(0, 0, star.size * 0.4, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      animationId = requestAnimationFrame(updateAndDraw);
    };

    animationId = requestAnimationFrame(updateAndDraw);

    // Emit beautiful small star trails on cursor position
    const emitStarTrail = (x: number, y: number) => {
      // Warm magical golden and bright soft pastel colors
      const starColors = ['#ffffff', '#fef08a', '#fde047', '#f472b6', '#a78bfa', '#60a5fa', '#34d399', '#fbbf24', '#ffedd5'];
      const types: ('sparkle' | 'star' | 'circle')[] = ['sparkle', 'star', 'circle', 'sparkle'];
      
      // Emit 3 to 5 stars per movement for a beautiful dense trail of small sparkles
      const count = Math.floor(Math.random() * 3) + 3;
      for (let k = 0; k < count; k++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 1.5 + 0.3;
        stars.push({
          id: starIdCounter++,
          x: x + (Math.random() - 0.5) * 6,
          y: y + (Math.random() - 0.5) * 6,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed - 0.1, // very slight upward bias
          size: Math.random() * 4 + 2, // Small stars (2px to 6px)
          color: starColors[Math.floor(Math.random() * starColors.length)],
          alpha: 0.95 + Math.random() * 0.05,
          decay: Math.random() * 0.05 + 0.04, // extremely fast decay (vanishes in ~15-20 frames / 200-300ms)
          rotation: Math.random() * Math.PI,
          rotationSpeed: (Math.random() - 0.5) * 0.1,
          type: types[Math.floor(Math.random() * types.length)]
        });
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      emitStarTrail(e.clientX, e.clientY);
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches[0]) {
        emitStarTrail(e.touches[0].clientX, e.touches[0].clientY);
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('touchmove', handleTouchMove);

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('touchmove', handleTouchMove);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-[100] overflow-hidden">
      {/* High-performance star rendering canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
    </div>
  );
}
