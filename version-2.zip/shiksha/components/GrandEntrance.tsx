import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Lock } from 'lucide-react';

const butterflyColors = ['#f472b6', '#60a5fa', '#34d399', '#fbbf24', '#c084fc', '#f87171', '#38bdf8'];

function ExplosionButterfly() {
  const color = butterflyColors[Math.floor(Math.random() * butterflyColors.length)];
  
  const anim = useMemo(() => {
    const angle = Math.random() * Math.PI * 2;
    const distance = 500 + Math.random() * 1000;
    return {
      x: Math.cos(angle) * distance,
      y: Math.sin(angle) * distance,
      duration: 1.5 + Math.random() * 2,
    };
  }, []);

  return (
    <motion.div
      className="absolute w-6 h-6 z-50 pointer-events-none"
      style={{ top: '50%', left: '50%', filter: `drop-shadow(0 0 8px ${color})` }}
      initial={{ x: 0, y: 0, scale: 0, opacity: 0 }}
      animate={{
        x: anim.x,
        y: anim.y,
        scale: [0, 1.5, 1],
        opacity: [0, 1, 0],
      }}
      transition={{ duration: anim.duration, ease: "easeOut" }}
    >
        {/* Right Wing */}
        <motion.div
          className="absolute inset-0 origin-left w-1/2 left-1/2"
          animate={{ rotateY: [0, -75, 0] }}
          transition={{ duration: 0.1, repeat: Infinity, ease: 'linear' }}
        >
          <svg viewBox="0 0 50 100" className="w-full h-full" style={{ color }} fill="currentColor">
              <path d="M 0 50 C 50 10, 60 40, 5 50 C 60 60, 50 90, 0 50 Z" />
          </svg>
        </motion.div>
        {/* Left Wing */}
        <motion.div
          className="absolute inset-0 origin-right w-1/2"
          animate={{ rotateY: [0, 75, 0] }}
          transition={{ duration: 0.1, repeat: Infinity, ease: 'linear' }}
        >
          <svg viewBox="0 0 50 100" className="w-full h-full" style={{ color }} fill="currentColor">
              <path d="M 50 50 C 0 10, -10 40, 45 50 C -10 60, 0 90, 50 50 Z" />
          </svg>
        </motion.div>
    </motion.div>
  );
}

export function GrandEntrance({ onEnter }: { onEnter: () => void }) {
  const [isUnlocking, setIsUnlocking] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const handleUnlock = () => {
    setIsUnlocking(true);
    setTimeout(() => {
      setIsOpen(true);
      setTimeout(() => {
        onEnter();
      }, 1500);
    }, 400);
  };

  return (
    <motion.div 
      exit={{ opacity: 0, pointerEvents: "none" }}
      transition={{ duration: 1.5, ease: "easeInOut", delay: 1 }}
      className="fixed inset-0 z-[100] bg-[#050810] flex items-center justify-center overflow-hidden"
    >
      {/* Forest Background Elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#0f2e24_0%,_#050810_100%)] opacity-90" />
      
      {/* Fireflies in the dark */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1.5 h-1.5 bg-emerald-300 rounded-full"
            style={{
              top: Math.random() * 100 + '%',
              left: Math.random() * 100 + '%',
              boxShadow: '0 0 12px 3px rgba(52, 211, 153, 0.6)'
            }}
            animate={{
              y: [0, -40, 0],
              x: [0, Math.random() * 40 - 20, 0],
              opacity: [0, 0.8, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 5,
              repeat: Infinity,
              delay: Math.random() * 5
            }}
          />
        ))}
      </div>

      <AnimatePresence>
        {!isOpen && (
          <motion.div
            exit={{ scale: 1.5, opacity: 0, filter: 'blur(20px)' }}
            transition={{ duration: 1.2, ease: "easeInOut" }}
            className="z-20 flex flex-col items-center absolute"
          >
            <motion.button
              onClick={handleUnlock}
              disabled={isUnlocking}
              animate={isUnlocking ? { scale: [1, 1.1, 0.9], opacity: [1, 0.5, 0] } : {}}
              whileTap={{ scale: 0.95 }}
              transition={{ duration: 0.8 }}
              className="group cursor-pointer flex flex-col items-center outline-none transition-all duration-150"
            >
              <div className="mb-4">
              </div>
              <h1 className="text-5xl md:text-7xl text-emerald-100 font-serif mb-6 tracking-widest drop-shadow-[0_0_30px_rgba(52,211,153,0.6)] group-hover:drop-shadow-[0_0_50px_rgba(52,211,153,0.9)] group-hover:text-white transition-all duration-500 flex items-center justify-center">
                {"SHIKSHA".split("").map((char, index) => (
                  <motion.span
                    key={index}
                    initial={{ opacity: 0, display: 'none' }}
                    animate={{ opacity: 1, display: 'inline-block' }}
                    transition={{ delay: index * 0.2, duration: 0.1 }}
                  >
                    {char}
                  </motion.span>
                ))}
                <motion.span
                   animate={{ opacity: [1, 0, 1] }}
                   transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                   className="inline-block ml-2 w-[4px] h-[60px] md:h-[80px] bg-emerald-100/80 shadow-[0_0_10px_rgba(52,211,153,0.8)]"
                />
              </h1>
              
              {!isUnlocking && (
                <motion.div 
                   animate={{ opacity: [0.3, 1, 0.3], y: [0, 5, 0] }}
                   transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                   className="text-emerald-300/80 tracking-[0.4em] uppercase text-sm font-light font-sans"
                >
                  Click to Enter
                </motion.div>
              )}
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Butterfly Explosion */}
      {isOpen && (
        <div className="absolute inset-0 pointer-events-none z-30">
          {[...Array(80)].map((_, i) => (
            <ExplosionButterfly key={i} />
          ))}
        </div>
      )}
    </motion.div>
  );
}
