import React, { useState, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Camera, Calendar, Check, Edit2, MapPin, ChevronDown } from 'lucide-react';
import { usePersistentState } from '../lib/usePersistentState';
import { MediaUpload } from './MediaUpload';

const NEON_COLORS = [
  { start: '#ff007f', end: '#cc0066', glow: '#ff1493' }, // Pink
  { start: '#00e5ff', end: '#00b2cc', glow: '#00ffff' }, // Cyan
  { start: '#39ff14', end: '#2ecc10', glow: '#32cd32' }, // Green
  { start: '#8a2be2', end: '#6a1baf', glow: '#9370db' }, // Purple
  { start: '#ff5e00', end: '#cc4b00', glow: '#ff8c00' }, // Orange
  { start: '#ffff00', end: '#b8b800', glow: '#ffea00' }  // Yellow
];

function LanternCard({ date, color, glow, delay }: { date: string, color: string, glow: string, delay: number }) {
  const year = date.substring(0, 5);
  const monthDay = date.substring(5);
  return (
    <div className="relative flex flex-col items-center justify-center w-[84px] h-[120px] group">
      {/* Intense Neon Glow Behind */}
      <div 
        className="absolute inset-[-18px] rounded-[30px] blur-[24px]" 
        style={{ 
          backgroundColor: glow,
          opacity: 0.9,
        }} 
      />
      
      {/* Card Body */}
      <div 
        className="relative w-full h-full rounded-[20px] border-[1px] flex flex-col items-center justify-center z-10 backdrop-blur-xl overflow-hidden"
        style={{ 
          background: `linear-gradient(135deg, ${color}99 0%, ${color}33 100%)`,
          borderColor: `rgba(255, 255, 255, 0.5)`,
          boxShadow: `inset 0 0 25px ${color}80, 0 0 30px ${glow}90, inset 0px 2px 5px rgba(255,255,255,0.6)`,
        }}
      >
        {/* Glass Reflection Highlight */}
        <div className="absolute top-0 left-0 right-0 h-1/2 bg-gradient-to-b from-white/50 to-transparent pointer-events-none" />
        {/* Glass Edge Left */}
        <div className="absolute top-0 left-0 bottom-0 w-1 bg-gradient-to-r from-white/30 to-transparent pointer-events-none" />
        
        <Camera size={28} className="text-white mb-2 z-10" strokeWidth={1.5} style={{ filter: 'drop-shadow(0px 2px 6px rgba(0,0,0,0.8))' }} />
        <div className="text-[12px] font-mono font-bold text-white leading-[1.2] text-center z-10 tracking-widest" style={{ filter: 'drop-shadow(0px 2px 6px rgba(0,0,0,0.9))' }}>
          {year}<br/>{monthDay}
        </div>
      </div>
    </div>
  );
}

const generateLanterns = () => {
  const generated = [];
  for (let i = 0; i < 40; i++) {
    const date = new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000);
    const colorPair = NEON_COLORS[Math.floor(Math.random() * NEON_COLORS.length)];
    generated.push({
      id: i + 1,
      delay: Math.random() * 20,
      left: Math.random() * 4000 - 2000,
      text: "",
      date: date.toISOString().split('T')[0],
      colorStart: colorPair.start,
      colorEnd: colorPair.end,
      glowColor: colorPair.glow,
      mediaUrl: null as string | null,
      mediaFile: null as Blob | null,
      mediaType: null as string | null,
      mediaName: null as string | null
    });
  }
  return generated.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export function Lanterns() {
  const [lanternData, setLanternData, isLoadedLanterns] = usePersistentState('lanterns_data', generateLanterns);
  const [activeLantern, setActiveLantern, isLoadedActive] = usePersistentState<number | null>('lanterns_active', null);
  const [persistentPan, setPersistentPan, isLoadedPan] = usePersistentState('lanterns_pan', { x: 0, y: 0 });
  const panRef = useRef({ x: 0, y: 0 });
  const panContainerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (isLoadedPan) {
      panRef.current = { ...persistentPan };
      if (panContainerRef.current) {
        panContainerRef.current.style.transform = `translateX(${persistentPan.x}px)`;
      }
    }
  }, [isLoadedPan]);

  const [isPanning, setIsPanning] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const lastPos = useRef({ x: 0, y: 0 });
  const [searchDate, setSearchDate] = useState("");
  const [highlightId, setHighlightId] = useState<number | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState("");
  const [editDate, setEditDate] = useState("");

  const handlePointerDown = (e: React.PointerEvent) => {
    if (activeLantern) return;
    setIsPanning(true);
    lastPos.current = { x: e.clientX, y: e.clientY };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isPanning || activeLantern) return;
    const dx = e.clientX - lastPos.current.x;
    panRef.current.x += dx;
    if (panContainerRef.current) {
      panContainerRef.current.style.transform = `translateX(${panRef.current.x}px)`;
    }
    lastPos.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerUp = (e: React.PointerEvent) => { setIsPanning(false); setPersistentPan({ ...panRef.current }); };

  const handleFileUpload = (lanternId: number, file: File) => {
    const url = URL.createObjectURL(file);
    setLanternData(lanternData.map(l => l.id === lanternId ? { ...l, mediaUrl: url, mediaFile: file, mediaType: file.type, mediaName: file.name } : l));
  };

  const goToPresent = () => {
    panRef.current = { x: 0, y: 0 }; setPersistentPan({ x: 0, y: 0 }); if (panContainerRef.current) { panContainerRef.current.style.transition = 'transform 0.5s ease'; panContainerRef.current.style.transform = 'translateX(0px)'; setTimeout(() => { if (panContainerRef.current) panContainerRef.current.style.transition = 'none'; }, 500); }
    if (lanternData.length > 0) {
      setHighlightId(lanternData[0].id);
      setTimeout(() => setHighlightId(null), 3000);
    }
  };

  const { oldestDate, latestDate } = useMemo(() => {
    if (lanternData.length === 0) return { oldestDate: '-', latestDate: '-' };
    const sorted = [...lanternData].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    return {
      oldestDate: sorted[0].date,
      latestDate: sorted[sorted.length - 1].date
    };
  }, [lanternData]);

  const backgroundStars = useMemo(() => [...Array(50)].map((_, i) => (
    <div key={i} className="absolute rounded-full bg-[#ffaa55]" style={{
      width: Math.random() * 3 + 'px',
      height: Math.random() * 3 + 'px',
      left: Math.random() * 100 + '%',
      top: Math.random() * 100 + '%',
      opacity: Math.random() * 0.5 + 0.1,
      boxShadow: `0 0 ${Math.random() * 10 + 5}px rgba(255,255,255,0.8)`,
    }} />
  )), []);

  if (!isLoadedLanterns || !isLoadedActive || !isLoadedPan) return null;

  return (
    <div 
      className="relative w-full h-[80vh] min-h-[500px] overflow-hidden touch-none select-none bg-slate-950"
      ref={containerRef}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
      onPointerCancel={handlePointerUp}
    >
      {/* Background with stars/fireflies */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#3a1c32] via-[#2d1a3b] to-[#251630]">
        {backgroundStars}
      </div>

      <div className="absolute top-10 left-1/2 -translate-x-1/2 z-50 pointer-events-auto flex flex-col items-center w-full px-4">
        <div className="bg-[#120a1f]/80 backdrop-blur-md rounded-[2.5rem] py-4 px-8 border border-[#00e5ff]/40 shadow-[0_0_20px_rgba(0,229,255,0.1)] flex flex-col items-center gap-3 max-w-[280px] w-full">
          <h2 className="text-2xl md:text-3xl font-serif text-white tracking-wide whitespace-nowrap">Floating Memories</h2>
          <div className="flex items-center gap-2 bg-[#0a0514]/80 rounded-full px-4 py-2 border border-[#00e5ff]/30 w-full relative">
            <Calendar size={16} className="text-[#00e5ff]" />
            <input 
              type="date" 
              value={searchDate} 
              onChange={e => {
                setSearchDate(e.target.value);
                const target = lanternData.find(l => l.date === e.target.value);
                if (target) {
                  panRef.current = { x: -target.left, y: 0 }; setPersistentPan({ x: -target.left, y: 0 }); if (panContainerRef.current) { panContainerRef.current.style.transition = 'transform 0.5s ease'; panContainerRef.current.style.transform = `translateX(${-target.left}px)`; setTimeout(() => { if (panContainerRef.current) panContainerRef.current.style.transition = 'none'; }, 500); }
                  setHighlightId(target.id);
                  setTimeout(() => setHighlightId(null), 3000);
                }
              }} 
              className="bg-transparent outline-none text-[#00e5ff] text-sm font-medium w-full relative z-10 [&::-webkit-calendar-picker-indicator]:opacity-0 [&::-webkit-calendar-picker-indicator]:absolute [&::-webkit-calendar-picker-indicator]:w-full" 
              style={{ colorScheme: 'dark' }} 
            />
            <ChevronDown size={16} className="text-[#00e5ff] absolute right-4 pointer-events-none" />
          </div>
        </div>
      </div>

      <div ref={panContainerRef} className="absolute inset-0 w-full h-full will-change-transform">
        {lanternData.map(lantern => (
          <div
            key={lantern.id}
            className={`absolute flex flex-col items-center cursor-pointer transition-transform duration-300 hover:scale-110 ${highlightId === lantern.id ? 'scale-125 z-40' : 'z-10'}`}
            style={{ 
              left: `calc(50% + ${lantern.left}px)`,
              animation: `rise-up-sway ${40 + lantern.delay}s linear infinite`,
              animationDelay: `-${(lantern.delay / 20) * (40 + lantern.delay)}s`
            }}
            onClick={() => { setActiveLantern(lantern.id); setEditValue(lantern.text); setEditDate(lantern.date); }}
          >
             <LanternCard 
               date={lantern.date}
               color={lantern.colorStart} 
               glow={lantern.glowColor} 
               delay={lantern.delay} 
             />
          </div>
        ))}
      </div>

      <div className="absolute bottom-4 sm:bottom-6 left-0 right-0 px-4 md:px-8 z-40 flex flex-col-reverse sm:flex-row justify-between items-center sm:items-end gap-3 sm:gap-4 pointer-events-none">
        <div className="bg-[#121c22]/90 backdrop-blur-md rounded-full px-5 py-2.5 sm:px-6 sm:py-3 border border-[#00e5ff]/30 text-[#88aab5] text-[12px] sm:text-[13px] tracking-wider text-center pointer-events-auto shadow-[0_0_20px_rgba(0,229,255,0.2)]">
          Oldest: {oldestDate}
        </div>
        
        <button 
          onClick={goToPresent}
          className="pointer-events-auto bg-[#0b1b24]/90 backdrop-blur-md rounded-full px-5 py-3 sm:px-6 sm:py-3 border-2 border-[#00e5ff] shadow-[0_0_30px_rgba(0,229,255,0.7)] text-white text-[12px] sm:text-[13px] font-bold text-center uppercase tracking-widest transition-transform active:scale-95 hover:shadow-[0_0_40px_rgba(0,229,255,0.9)] w-full sm:w-auto"
        >
          LATEST MEMORY ADDED:<br className="sm:hidden" /> <span className="hidden sm:inline"></span>{latestDate}
        </button>
      </div>

      <AnimatePresence>
        {activeLantern && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="absolute inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm pointer-events-auto"
            onClick={() => { setActiveLantern(null); setIsEditing(false); }}
          >
            <div className="bg-[#0f0714] border border-fuchsia-900/50 p-6 rounded-2xl w-full max-w-lg shadow-[0_0_50px_rgba(217,70,239,0.15)] flex flex-col gap-4" onClick={e => e.stopPropagation()}>
               {(() => {
                 const current = lanternData.find(l => l.id === activeLantern)!;
                 return (
                   <>
                     <div className="w-full h-[300px] rounded-lg overflow-hidden border border-fuchsia-900/30 bg-black/50 relative">
                       <MediaUpload 
                         mediaUrl={current.mediaUrl}
                         mediaType={current.mediaType}
                         mediaName={current.mediaName}
                         onUpload={(file) => handleFileUpload(current.id, file)}
                         className="w-full h-full"
                       />
                       {/* Decor glow */}
                       <div className="absolute -top-10 -right-10 w-32 h-32 rounded-full blur-3xl opacity-20" style={{ background: current.glowColor }} />
                     </div>
                     <div className="flex items-center gap-2 justify-between">
                       <div className="flex items-center gap-2 text-fuchsia-300/70 text-xs font-mono">
                         <Calendar size={14} />
                         {isEditing ? <input type="date" value={editDate} onChange={e => setEditDate(e.target.value)} className="bg-transparent border-b border-fuchsia-500/50 outline-none text-fuchsia-100" /> : current.date}
                       </div>
                       {!isEditing && <Edit2 size={14} className="text-fuchsia-500/50 cursor-pointer hover:text-fuchsia-300 transition-colors" onClick={() => setIsEditing(true)} />}
                     </div>
                     {isEditing ? (
                       <div className="flex gap-2">
                         <input autoFocus type="text" value={editValue} onChange={e => setEditValue(e.target.value)} onKeyDown={e => e.key === 'Enter' && (setLanternData(lanternData.map(l => l.id === activeLantern ? { ...l, text: editValue, date: editDate } : l)), setIsEditing(false))} className="flex-1 bg-black/50 border border-fuchsia-900/50 rounded-lg px-4 py-3 text-fuchsia-100 outline-none focus:border-fuchsia-500/50 transition-colors" placeholder="Write a message for the sky..." />
                         <button onClick={() => { setLanternData(lanternData.map(l => l.id === activeLantern ? { ...l, text: editValue, date: editDate } : l)); setIsEditing(false); }} className="bg-fuchsia-600 hover:bg-fuchsia-500 text-white px-4 rounded-lg transition-colors"><Check size={18} /></button>
                       </div>
                     ) : (
                       <p className="text-fuchsia-100/90 text-[15px] italic font-serif text-center cursor-pointer hover:bg-fuchsia-900/20 p-4 rounded-xl transition-colors min-h-[60px] flex items-center justify-center leading-relaxed" onClick={() => setIsEditing(true)}>{current.text || "Click to add a memory..."}</p>
                     )}
                   </>
                 );
               })()}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
