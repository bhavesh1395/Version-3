import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Lock } from 'lucide-react';

export function LoginScreen({ savedPassword, onLogin }: { savedPassword: string, onLogin: () => void }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === savedPassword) {
      onLogin();
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-[#050810] flex flex-col items-center justify-center p-4">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#0f2e24_0%,_#050810_100%)] opacity-60" />
      
      <motion.form 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        onSubmit={handleSubmit}
        className="w-full max-w-sm flex flex-col items-center gap-6 relative z-10"
      >
        <div className="text-center mb-4 flex flex-col items-center">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-serif font-bold animate-neon-text mt-4 mb-2 tracking-wide text-center">MY SHIKSHA</h1>
            <p className="text-emerald-200/60 font-light text-xs tracking-widest uppercase mt-2">Please enter the password</p>
        </div>

        <div className="w-full relative">
            <input 
            type="password" 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={`w-full bg-black/40 border ${error ? 'border-red-500/50 shadow-[0_0_15px_rgba(239,68,68,0.3)]' : 'border-white/10'} rounded-full px-6 py-4 text-white text-center outline-none focus:border-emerald-500/60 focus:bg-black/60 transition-all backdrop-blur-md`}
            placeholder="Enter password..."
            />
            {error && (
               <motion.p 
                 initial={{ opacity: 0, y: -10 }}
                 animate={{ opacity: 1, y: 0 }}
                 className="text-red-400 text-xs absolute -bottom-6 left-0 right-0 text-center"
               >
                 Incorrect password
               </motion.p>
            )}
        </div>
        
        <button 
           type="submit" 
           className="mt-4 bg-emerald-500/20 hover:bg-emerald-500/40 border border-emerald-500/50 text-emerald-100 px-10 py-3 rounded-full transition-all tracking-wide text-sm font-medium hover:scale-105 active:scale-95"
        >
          Unlock
        </button>
      </motion.form>
    </div>
  )
}
