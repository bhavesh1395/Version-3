import React, { useRef } from 'react';
import { Camera, File, FileText, Music, Video, Plus } from 'lucide-react';

interface MediaUploadProps {
  mediaUrl: string | null;
  mediaType: string | null;
  mediaName: string | null;
  onUpload: (file: File) => void;
  className?: string;
}

export function MediaUpload({ mediaUrl, mediaType, mediaName, onUpload, className = "" }: MediaUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleClick = (e: React.MouseEvent) => {
    // Only trigger upload if clicking on the container itself or the change overlay
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUpload(file);
    }
  };

  const renderMedia = () => {
    if (!mediaUrl || !mediaType) return null;

    if (mediaType.startsWith('image/')) {
      return <img src={mediaUrl} alt={mediaName || 'Uploaded media'} className="w-full h-full object-cover" />;
    }
    if (mediaType.startsWith('video/')) {
      return (
        <div className="w-full h-full bg-black flex items-center justify-center relative" onClick={e => e.stopPropagation()}>
          <video src={mediaUrl} controls className="w-full max-h-full object-contain" />
          <div className="absolute top-2 right-2 p-1 bg-black/50 rounded text-white cursor-pointer hover:bg-black/80" onClick={() => fileInputRef.current?.click()}>
            <Camera size={16} />
          </div>
        </div>
      );
    }
    if (mediaType.startsWith('audio/')) {
      return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-indigo-50 p-4 gap-4" onClick={e => e.stopPropagation()}>
          <Music size={48} className="text-indigo-400" />
          <audio src={mediaUrl} controls className="w-full max-w-[200px]" />
          <span className="text-xs text-center truncate w-full text-indigo-800">{mediaName}</span>
          <div className="absolute top-2 right-2 p-1 bg-black/20 rounded text-black cursor-pointer hover:bg-black/30" onClick={() => fileInputRef.current?.click()}>
            <Camera size={16} />
          </div>
        </div>
      );
    }
    if (mediaType === 'application/pdf') {
      return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-red-50 p-4 gap-2 text-red-500" onClick={e => e.stopPropagation()}>
           <FileText size={48} />
           <span className="text-xs text-center truncate w-full" title={mediaName || ''}>{mediaName}</span>
           <a href={mediaUrl} target="_blank" rel="noreferrer" className="text-xs underline font-medium">View PDF</a>
           <div className="absolute top-2 right-2 p-1 bg-black/10 rounded text-black cursor-pointer hover:bg-black/20" onClick={() => fileInputRef.current?.click()}>
            <Camera size={16} />
          </div>
        </div>
      );
    }
    
    return (
      <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 p-4 gap-2 text-slate-500" onClick={e => e.stopPropagation()}>
         <File size={48} />
         <span className="text-xs text-center truncate w-full" title={mediaName || ''}>{mediaName}</span>
         <a href={mediaUrl} download={mediaName || 'file'} className="text-xs underline font-medium">Download File</a>
         <div className="absolute top-2 right-2 p-1 bg-black/10 rounded text-black cursor-pointer hover:bg-black/20" onClick={() => fileInputRef.current?.click()}>
            <Camera size={16} />
          </div>
      </div>
    );
  };

  return (
    <div 
      className={`relative cursor-pointer overflow-hidden group ${className}`}
      onClick={!mediaUrl || mediaType?.startsWith('image/') ? handleClick : undefined}
    >
      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        className="hidden" 
        accept="image/*,video/*,audio/*,application/pdf,.doc,.docx,.txt"
      />
      
      {mediaUrl ? (
        <>
          {renderMedia()}
          {mediaType?.startsWith('image/') && (
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white">
              <div className="flex flex-col items-center gap-2">
                <Camera size={32} />
                <span className="text-sm font-medium uppercase tracking-wider text-center">Change<br/>Media</span>
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950 p-4" onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}>
          <span className="text-sm font-medium uppercase tracking-widest text-slate-300 mb-6 drop-shadow-[0_0_8px_rgba(255,255,255,0.5)]">Select Media Type</span>
          <div className="grid grid-cols-3 gap-4 w-full max-w-[280px]">
            {[
              { icon: Camera, label: 'Photo', color: 'text-pink-400', border: 'border-pink-500/50', glow: 'shadow-[0_0_15px_rgba(244,114,182,0.4)]', hover: 'hover:shadow-[0_0_25px_rgba(244,114,182,0.8)]' },
              { icon: Video, label: 'Video', color: 'text-cyan-400', border: 'border-cyan-500/50', glow: 'shadow-[0_0_15px_rgba(34,211,238,0.4)]', hover: 'hover:shadow-[0_0_25px_rgba(34,211,238,0.8)]' },
              { icon: Music, label: 'Audio', color: 'text-purple-400', border: 'border-purple-500/50', glow: 'shadow-[0_0_15px_rgba(192,132,252,0.4)]', hover: 'hover:shadow-[0_0_25px_rgba(192,132,252,0.8)]' },
              { icon: FileText, label: 'PDF', color: 'text-emerald-400', border: 'border-emerald-500/50', glow: 'shadow-[0_0_15px_rgba(52,211,153,0.4)]', hover: 'hover:shadow-[0_0_25px_rgba(52,211,153,0.8)]' },
              { icon: File, label: 'Doc', color: 'text-amber-400', border: 'border-amber-500/50', glow: 'shadow-[0_0_15px_rgba(251,191,36,0.4)]', hover: 'hover:shadow-[0_0_25px_rgba(251,191,36,0.8)]' },
              { icon: Plus, label: 'Other', color: 'text-blue-400', border: 'border-blue-500/50', glow: 'shadow-[0_0_15px_rgba(96,165,250,0.4)]', hover: 'hover:shadow-[0_0_25px_rgba(96,165,250,0.8)]' },
            ].map((btn, i) => {
              const Icon = btn.icon;
              return (
                <div 
                  key={i}
                  className={`flex flex-col items-center justify-center p-3 rounded-xl bg-slate-900 border ${btn.border} ${btn.glow} ${btn.hover} transition-all duration-300 cursor-pointer hover:scale-105 active:scale-95`}
                >
                  <Icon size={24} className={`${btn.color} drop-shadow-[0_0_8px_currentColor] mb-2`} />
                  <span className={`text-[10px] uppercase font-bold tracking-wider ${btn.color} opacity-90`}>{btn.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
