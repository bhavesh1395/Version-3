import localforage from 'localforage';

export const store = localforage.createInstance({
  name: 'shiksha_app_db',
  storeName: 'shiksha_store'
});

export const saveMedia = async (key: string, file: File) => {
  return store.setItem(key, file);
};

export const getMedia = async (key: string) => {
  return store.getItem<File>(key);
};
