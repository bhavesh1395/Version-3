const DB_NAME = 'shiksha_music_db';
const STORE_NAME = 'songs_store';

export function initDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 2);
    request.onupgradeneeded = (event: any) => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      } else {
        // If the store exists but without keyPath, we can't easily change it
        // A robust solution for production would handle migration better
        db.deleteObjectStore(STORE_NAME);
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveCustomSong(file: File): Promise<{id: string, name: string}> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const id = 'custom_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    const putRequest = store.put({
      id,
      blob: file,
      name: file.name,
      type: file.type
    });

    putRequest.onsuccess = () => resolve({ id, name: file.name });
    putRequest.onerror = () => reject(putRequest.error);
  });
}

export async function getCustomSong(id: string): Promise<{ blob: Blob; name: string; type: string } | null> {
  try {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const getRequest = store.get(id);

      getRequest.onsuccess = () => {
        resolve(getRequest.result || null);
      };
      getRequest.onerror = () => reject(getRequest.error);
    });
  } catch (e) {
    console.error('Failed to read from IndexedDB', e);
    return null;
  }
}

export async function getAllCustomSongs(): Promise<{ id: string, name: string }[]> {
  try {
    const db = await initDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const getRequest = store.getAll();

      getRequest.onsuccess = () => {
        const results = getRequest.result || [];
        resolve(results.map(r => ({ id: r.id, name: r.name })));
      };
      getRequest.onerror = () => reject(getRequest.error);
    });
  } catch (e) {
    console.error('Failed to get all songs', e);
    return [];
  }
}

export async function clearCustomSong(id: string): Promise<void> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const deleteRequest = store.delete(id);

    deleteRequest.onsuccess = () => resolve();
    deleteRequest.onerror = () => reject(deleteRequest.error);
  });
}
