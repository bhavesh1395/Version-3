export const PLAYLIST = [
  { id: 'song1', title: 'Beautiful Dream (Piano)', url: 'https://assets.mixkit.co/music/preview/mixkit-beautiful-dream-493.mp3' },
  { id: 'song2', title: 'Tender Affection', url: 'https://assets.mixkit.co/music/preview/mixkit-tender-affection-101.mp3' },
  { id: 'song3', title: 'Serene View (Ambient)', url: 'https://assets.mixkit.co/music/preview/mixkit-serene-view-1002.mp3' },
];
